# Datetime
from datetime import datetime

from asgiref.sync import sync_to_async
import asyncio
import collections
import concurrent.futures
import time
import random
import string
import httpx
import requests
import pandas as pd
import plotly.graph_objs as go

from plotly.offline import plot
from plotly.graph_objs import Scatter
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render, redirect
from django.views import generic
from django.http import HttpResponse
from django.views.generic import ListView
from matplotlib import pyplot as plt


from .localize import *
from .models import *

"""
def home_page(request, checkin_success=False):
    prof = False
    if not request.user.is_authenticated():
        return render(request, "../templates/login.html")
    if request.userprofile.group is int(1):
        prof = True
    request.session['status'] = ""
"""

# This function returns the courses available for attendance logging
# For user with group category of student
def get_courses_for_attendance(request):
    # TODO: Atm, it does not check if the student is a member of the course
    #   Add line ,filter().filter(classcoursemember)
    user = request.user
    user = UserProfile.objects.get(user=user)
 
    # Objects refer to attendance session with courses open for attendance
    # Int 0 refers to OPEN 
    courses = AttendanceSession.objects.all().filter(status=int(0))
    return courses


def get_attendees_list(request):
    user = request.user
    user = UserProfile.objects.get(user=user)
    # Only view courses that are the professor's and are open
    attendance_object = AttendanceSession.objects.get(course__instructor=user,status=int(0))
    objects = AttendanceMember.objects.all().filter(session = attendance_object)
    return objects


# FFStudents
def get_random_string():
    length = 8
    # choose from all lowercase letter
    letters = string.ascii_lowercase
    result_str = ''.join(random.choice(letters) for i in range(length))
    # print("Random string of length", length, "is:", result_str)
    return result_str



def home(request):
    user = request.user
    if not user.is_authenticated:
        return render(request, "../templates/index.html")

    else:
        user_obj = User.objects.get(username=user.username)
        options = get_courses_for_attendance(request)
        attendance = True

        student = False
        professor = False
        group = ''
        message = ''

        try:
            group = user_obj.userprofile.group

        except UserProfile.DoesNotExist:
            profile = UserProfile(user=user, group=int(0))
            profile.save()

        if group == int(0):
            student = True
        elif group == int(1):
            professor = True
        return render(request, "../templates/home.html", {'message':message,'attendance': attendance,'student': student,'professor': professor})


# This function processes log attendance request
@login_required
def attendance(request):
    user = request.user
    student = False
    professor = False
    user_obj = User.objects.get(username=user.username)
    options=''
    try:
        group = user_obj.userprofile.group
    except UserProfile.DoesNotExist:
        profile = UserProfile(user=user, group=int(0))
        profile.save()

    if group == int(0):
        student = True
        options = get_courses_for_attendance(request)
    elif group == int(1):
        professor = True
        user = UserProfile.objects.get(user=user_obj)
        options = AttendanceSession.objects.all().filter(status=int(0),course__instructor=user)

    if options:
        return render(request, "../templates/attendance.html", {'options': options,
                                                                'student': student,
                                                                'professor': professor})
    else:
        return redirect(home)


@login_required
def attendance_request(request):
    user = request.user
    student = False
    professor = False
    user_obj = User.objects.get(username=user.username) 
    group = user_obj.userprofile.group
    option=''
    userpf = UserProfile.objects.get(user=user)
    if group == int(0):
        student = True
    elif group == int(1):
        professor = True
    try:
        option = request.POST['option']
    except Exception as e:
        return render(request, "../templates/home.html", {'message': e})
    option_selected = AttendanceSession.objects.all().filter(pk=int(option))[0]

    # Create user's entry for attendance
    if student:
        course = option_selected.course.name
        message = ""
        user_key = ""
        if not AttendanceMember.objects.filter(user=user, session=option_selected).exists():
            # Save key value
            user_key = get_random_string()
            userpf.key=user_key
            userpf.save()

            entry = AttendanceMember.objects.create(user=user, session=option_selected)
            entry.save()
            #datetime.strptime(dt_string, "%d/%m/%Y %H:%M:%S")
            message = "Submitted! Attendee joined at {}".format(str(datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")))
        else:
            user_key = userpf.key
            entry = AttendanceMember.objects.all().filter(user=user, session=option_selected)[0]
            message = "Exists. Attendance recorded at {}".format((entry.timestamp).strftime("%d/%m/%Y %H:%M:%S"))
        return render(request, "../templates/attendance_success.html", {'message': message, 'course': course, 'user_key':user_key,})

    if professor:
        attendees = AttendanceMember.objects.all().filter(session = option_selected)
        course = option_selected.course.name
        message = main_localization(str(option_selected.session))
        return render(request, "../templates/attendees_list.html", {'message':message,'attendees': attendees, 'course':course})    
    
    else:
        return redirect(home)


@login_required
def course_map(request):
    user = request.user
    student = False
    professor = False
    user_obj = User.objects.get(username=user.username)
    group = user_obj.userprofile.group
    try:
        group = user_obj.userprofile.group
    except UserProfile.DoesNotExist:
        profile = UserProfile(user=user, group=int(0))
        profile.save()

    if group == int(0):
        student = True
    elif group == int(1):
        professor = True

    # Get all courses available
    options = get_courses_for_attendance(request)
    if options:
        return render(request, "../templates/courses_map.html", {'options': options, 'student': student, 'professor': professor})

    else:
        return redirect(home)


def plot_localized_data(sess):

    def get_node_xy_value(location1,location2,location3):
        node1_x,node1_y = get_scaled_points(int(location1))
        node2_x,node2_y = get_scaled_points(int(location2))
        node3_x,node3_y = get_scaled_points(int(location3))
        return node1_x, node1_y, node2_x, node2_y, node3_x, node3_y

    def get_scaled_points(location_int):
        if location_int == 0:
            x, y = int(-10), int(8)
        elif location_int == 1:
            x, y = int(10), int(8)
        elif location_int == 2:
            x, y = int(0), int(8)
        elif location_int == 3:
            x, y = int(-10), int(-8)
        elif location_int == 4:
            x, y = int(10), int(-8)
        elif location_int == 5:
            x, y = int(0), int(-8)
        else:
            x, y = int(99), int(99)
        return int(x),int(y)

    # Get bluetooth devices location
    attendance_session = AttendanceSession.objects.get(pk=int(sess.id))
    data = Localization.objects.all().filter(session = attendance_session)

    # List of graph objects for figure.
    # Each object will contain on series of data.
    graphs = []
    x_points = []
    y_points = []
    labels = []
    for each_student in data:
        i = (str(each_student.x_val))
        j = (str(each_student.y_val))
        x_points.append(float(i))
        y_points.append(float(j))
        labels.append(str(each_student.user))

    # Adding scatter plot of y2 vs. x. 
    graphs.append(
        go.Scatter(x=x_points, y=y_points, mode='markers+text', text=labels, opacity=0.8, marker_size=10, name='Students in Class', marker_color='blue')
    )

    go.add_layout_image(
        dict(
            source="/home/django/django_project/templates/classMap.png",
            xref="x",
            yref="y",
            sizing="stretch",
            opacity=0.5,
            layer="below")
)


    # Setting layout of the figure.
    layout = {
        'xaxis_title': 'X',
        'yaxis_title': 'Y',
        'height': 420,
        'width': 560,
    }

    location1=attendance_session.node1_location
    location2=attendance_session.node2_location
    location3=attendance_session.node3_location
    x1,y1,x2,y2,x3,y3 = get_node_xy_value(location1,location2,location3)

    graphs.append(
        go.Scatter(x=[x1,x2,x3], y=[y1,y2,y3], mode='markers+text', text=['node1', 'node2', 'node3'], opacity=0.8, marker_size=7, name='Anchor Nodes', marker_color='orange')
    )

    # Getting HTML needed to render the plot.
    plot_div = plot({'data': graphs, 'layout': layout}, 
                    output_type='div')

    return plot_div
    

"""
    def create(x_data, y_data, label):
        plt.rcParams["figure.figsize"] = [10.00, 8.0]
        plt.rcParams["figure.autolayout"] = True
        data = plt.imread("./templates/classMap.jpg")
        im = plt.imshow(data)
        
    #location1=attendance_session.node1_location
    #location2=attendance_session.node2_location
    #location3=attendance_session.node3_location
    #x1,y1,x2,y2,x3,y3 = get_node_xy_value(location1,location2,location3)
    
    # Get  students
    x_data,y_data=[],[]
    students = Localization.objects.all().filter(session=attendance_session)
    for each_student in students:
        x = each_student.x_val
        y = each_student.y_val
        x_data.append(x)
        y_data.append(y)

    x_arr = [x1,x2,x3]
    y_arr = [y1,y2,y3]
    plot_div = plot([Scatter(x=[x1,x2,x3], y=[y1,y2,y3], mode='lines', name='anchor nodes', opacity=0.8, marker_color='green')], output_type='div')
    
"""

@login_required
def course_map_request(request, type):
    user = request.user
    student = False
    professor = False
    user_obj = User.objects.get(username=user.username)
    group = user_obj.userprofile.group

    if group == int(0):
        student = True
    elif group == int(1):
        professor = True

    if type == 'new':
        try:
            option = request.POST['option']
        except Exception as e:
            return render(request, "../templates/home.html", {'message': e})
    else:
       option = request.option
    option_selected = AttendanceSession.objects.get(pk=int(option))

    # Create user's entry for attendance
    if professor:
        attendees = AttendanceMember.objects.all().filter(session = option_selected)
        ble_attendees = Localization.objects.all().filter(session = option_selected)
        course = option_selected.course.name
        location = option_selected.course.location
        message = main_localization(option_selected.session)

        if type=='new':
            plotted_div = plot_localized_data(option_selected)
            return render(request, "../templates/attendees_map.html", {'option':option,'message':message,'attendees': attendees, 'ble_attendees':ble_attendees,'course':course, 'location':location , 'plotted_div':plotted_div})
        else:
            return render(request, "../templates/attendees_map.html", {'option':option,'message':message,'attendees': attendees, 'course':course, 'location':location })
    else:
        return redirect(home)



# TODO: Add create class
# TODO: Add change class status, open to closed

