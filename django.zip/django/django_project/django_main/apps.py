from django.apps import AppConfig


class DjangoMainConfig(AppConfig):
    name = 'django_main'
