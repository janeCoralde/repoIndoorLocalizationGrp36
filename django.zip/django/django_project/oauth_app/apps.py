from django.apps import AppConfig


class OauthAppConfig(AppConfig):
    name = 'oauth_app'
