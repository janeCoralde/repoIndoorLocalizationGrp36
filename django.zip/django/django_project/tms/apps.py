from django.apps import AppConfig


class TmsConfig(AppConfig):
    name = 'tms'
