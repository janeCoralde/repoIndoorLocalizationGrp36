import plotly.graph_objs as go

from plotly.offline import plot
from plotly.graph_objs import Scatter
from .models import *


# All hardcoded values are located here
def get_scaled_points(location_int):
    # Top left, top middle, top right
    # Lower left, lower middle, lower right
    if location_int == 0:
        x, y = int(-10), int(8)
    elif location_int == 1:
        x, y = int(10), int(8)
    elif location_int == 2:
        x, y = int(0), int(8)
    elif location_int == 3:
        x, y = int(-10), int(-8)
    elif location_int == 4:
        x, y = int(10), int(-8)
    elif location_int == 5:
        x, y = int(0), int(-8)
    else:
        x, y = int(99), int(99)
    return int(x),int(y)


# Calls function for three nodes to get scaled HARDCODED points
def get_node_xy_value(location1,location2,location3):
    node1_x,node1_y = get_scaled_points(int(location1))
    node2_x,node2_y = get_scaled_points(int(location2))
    node3_x,node3_y = get_scaled_points(int(location3))
    return node1_x, node1_y, node2_x, node2_y, node3_x, node3_y


# Gets called after data is localized
# Returns the plotted div figure
def plot_localized_data(sess):

    # Get bluetooth devices location
    attendance_session = AttendanceSession.objects.get(pk=int(sess.id))
    data = Localization.objects.all().filter(session = attendance_session)

    # List of graph objects for figure.
    # Each object will contain on series of data.
    graphs = []
    x_points = []
    y_points = []
    labels = []

    # Get each student's X and Y
    for each_student in data:
        # Solution to format of value that is Decimal128
        i = (str(each_student.x_val))
        j = (str(each_student.y_val))
        x_points.append(float(i))
        y_points.append(float(j))
        labels.append(str(each_student.user))

    # Adding scatter plot of student
    graphs.append(
        go.Scatter(x=x_points, y=y_points, mode='markers+text', text=labels, opacity=0.8, marker_size=10, name='Students in Class', marker_color='blue')
    )


    # Setting layout of the figure.
    layout = {
        'xaxis_title': 'X',
        'yaxis_title': 'Y',
        'height': 420,
        'width': 560,
    }

    # Get node locations
    location1=attendance_session.node1_location
    location2=attendance_session.node2_location
    location3=attendance_session.node3_location
    x1,y1,x2,y2,x3,y3 = get_node_xy_value(location1,location2,location3)

    # Adding scatter plot of nodes 
    graphs.append(
        go.Scatter(x=[x1,x2,x3], y=[y1,y2,y3], mode='markers+text', text=['node1', 'node2', 'node3'], opacity=0.8, marker_size=7, name='Anchor Nodes', marker_color='orange')
    )

    # Getting HTML needed to render the plot.
    plot_div = plot({'data': graphs, 'layout': layout}, 
            output_type='div')

    return plot_div