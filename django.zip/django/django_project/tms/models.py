from django.db import models
from django.contrib.auth import get_user_model

# Get user model
from django.db.models.signals import post_save
from django.dispatch import receiver

User = get_user_model()


# UserProfile is an extension to the builtin User Model.
class UserProfile(models.Model):

    # Define model verbose name
    def __str__(self):
        return self.user.first_name + ' ' + self.user.last_name

    class Meta:  # This is a hack for the display of personal info on admin user add page
        verbose_name = 'Grouping Management'

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    student_id = models.TextField(blank=True, default='')
    key = models.TextField(blank=True, default='')
    group_category = (
        (0, 'Student'),
        (1, 'Professor'),
        (2, 'Teaching Assistant'),
        (3, 'Admin'),
    )
    group = models.IntegerField(default=0,
                                choices=group_category)


@receiver(post_save, sender=User)
def save_profile(sender, instance, created, **kwargs):
    user = instance
    if created:
        profile = UserProfile(user=user, group=int(0))
        profile.save()


class ClassCourse(models.Model):
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField(blank=True, default='')
    instructor = models.ForeignKey(UserProfile, null=True, on_delete=models.CASCADE, limit_choices_to={'group': int(1)},
                                   related_name="instructor")
    members = models.ManyToManyField(User, through="ClassCourseMember", related_name="members")
    location = models.CharField(max_length=255, help_text="Building and Room #")
    status_category = (
        (0, 'Fall Semester'),
        (1, 'Winter Semester')
    )
    status = models.IntegerField(default=1, choices=status_category)

    def student_names(self):
        return ", ".join([g.username for g in self.members.all()])

    student_names.short_description = "Student Names"

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Course'
        verbose_name_plural = 'Courses'
        ordering = ["name"]


"""
class ClassCourseInstructor(models.Model):
    classcourse = models.ForeignKey(ClassCourse, on_delete=models.CASCADE)
    instructor = models.ForeignKey(User, on_delete=models.CASCADE, limit_choices_to={'group': int(1)})

    def __str__(self):
        return self.instructor.username

    class Meta:
        unique_together = ("classcourse", "instructor")
"""


class ClassCourseMember(models.Model):
    classcourse = models.ForeignKey(ClassCourse, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, limit_choices_to={'group': int(0)})

    def __str__(self):
        return self.user.username

    class Meta:
        unique_together = ("classcourse", "user")

"""
class Localization(models.Model):
    class Meta:
        verbose_name = 'Localization Value'
        verbose_name_plural = 'Localization Values'

    # TODO : Add course fk
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rssi = models.DecimalField(max_digits=4, decimal_places=2, blank=True, default=None)
    session = models.ForeignKey(AttendanceSession, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    x_val = models.DecimalField(max_digits=4, decimal_places=2, blank=True, default=None)
    y_val = models.DecimalField(max_digits=4, decimal_places=2, blank=True, default=None)
"""

class AttendanceSession(models.Model):
    class Meta:
        verbose_name = 'Attendance Session'
        verbose_name_plural = 'Attendance Sessions'

    session = models.CharField(max_length=255, unique=True, default='')
    description = models.TextField(blank=True, default='')
    course = models.ForeignKey(ClassCourse, on_delete=models.CASCADE)
    members = models.ManyToManyField(User, through="AttendanceMember")
    status_category = (
        (0, 'Open - Accepting Attendance'),
        (1, 'Closed')
    )
    status = models.IntegerField(default=1, choices=status_category)
    helptext = "Please enter the bluetooth device's address"
    node1 = models.CharField(max_length=255, help_text=helptext)
    node2 = models.CharField(max_length=255, help_text=helptext)
    node3 = models.CharField(max_length=255, help_text=helptext)
    location_category = (
        (0, 'Left Top Side of Classroom (Left Side of the Blackboard)'),
        (1, 'Right Top Side of Classroom (Right Side of the Blackboard)'),
        (2, 'Middle Top Side of Classroom (By Lecturers Podium)'),
        (3, 'Left Bottom Side of Classroom'),
        (4, 'Right Bottom Side of Classroom'),
        (5, 'Middle Bottom Side of Classroom')
    )
    node1_location = models.IntegerField(default=0, choices=location_category)
    node2_location = models.IntegerField(default=1, choices=location_category)
    node3_location = models.IntegerField(default=5, choices=location_category)
    def student_names(self):
        return ", ".join([g.username for g in self.members.all()])

    student_names.short_description = "Student Names"

    def __str__(self):
        return self.course.name + "|" + self.session


class Localization(models.Model):
    class Meta:
        verbose_name = 'Localization Value'
        verbose_name_plural = 'Localization Values'

    # TODO : Add course fk
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rssi = models.DecimalField(max_digits=6, decimal_places=2, blank=True, default=None)
    session = models.ForeignKey(AttendanceSession, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    x_val = models.DecimalField(max_digits=6, decimal_places=2, blank=True, default=None)
    y_val = models.DecimalField(max_digits=6, decimal_places=2, blank=True, default=None)


class AttendanceMember(models.Model):
    session = models.ForeignKey(AttendanceSession, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.first_name + " " + \
               self.user.last_name  + " logged in at " + \
               str(self.timestamp.strftime("%Y-%m-%d %H:%M:%S"))

    class Meta:
        unique_together = ("session", "user")

