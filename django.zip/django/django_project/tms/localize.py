import datetime
import numpy as np
from bson import timestamp
from .models import *

# global variables
nanumber = 8

errkey_value = "error-key-student"

collect_name="apr181"
student_list_arr = []
student_data_arr = []
student_location_arr = []
close_objs = []
x1,y1,x2,y2,x3,y3="","","","","",""
close_proximity_value = 80  # TODO: Change variable to filter and decide at what signal is considered close
CONNECTION_STRING = r'mongodb+srv://capstoneadmin:47rExjahc81V2905@mongodb-db-capstoneproject-cd07d298.mongo.ondigitalocean.com/pymongo?authSource=admin&replicaSet=mongodb-db-capstoneproject&tls=true&tlsCAFile=./ca-certificate.crt'

def get_database():
    # Create a connection using MongoClient. You can import MongoClient or use pymongo.MongoClient
    from pymongo import MongoClient
    client = MongoClient(CONNECTION_STRING)

    # Create the database for our example (we will use the same database throughout the tutorial
    return client['rssiReceived']


def markTime():
    from datetime import datetime
    # Getting the current date and time
    dt = datetime.now()
    return dt


def dbColToArr(input_collection):
    for listData in input_collection:
        # Checks if the student is a NEW item
        # To count how many users have sent their info
        # To validate num of users
        if str(listData[1]) not in student_list_arr:
            student_list_arr.append(str(listData[1]))

        # TODO: To enhance collected meaningful data, tweak it from this side
        # Appends only the important values
        #   index1 is STUDENT ID
        #   index2 is BLE DEVICE ADDRESS
        #   index4 is AVERAGE FILTERED RSSI
        #   index6 is DISTANCE FILTERED
        #   index7 is TIMESTAMP
        d = [str(listData[1]),
             str(listData[2]),
             float(listData[4]),
             float(listData[6]),
             str(listData[7]),
             float(listData[5])]
        student_data_arr.append(d)
    return


def getNodeLocation(identifier):
    # get attendance session
    attendance_session = AttendanceSession.objects.all().filter(session=identifier)[0]
    location1=attendance_session.node1_location
    location2=attendance_session.node2_location
    location3=attendance_session.node3_location

    def get_scaled_points(location_int):
        if location_int == 0:
            x, y = int(-10), int(8)
        elif location_int == 1:
            x, y = int(10), int(8)
        elif location_int == 2:
            x, y = int(0), int(8)
        elif location_int == 3:
            x, y = int(-10), int(-8)
        elif location_int == 4:
            x, y = int(10), int(-8)
        elif location_int == 5:
            x, y = int(0), int(-8)
        else:
            x, y = int(99), int(99)
        return int(x),int(y)

    def get_node_xy_value():
        node1_x,node1_y = get_scaled_points(int(location1))
        node2_x,node2_y = get_scaled_points(int(location2))
        node3_x,node3_y = get_scaled_points(int(location3))
        return node1_x, node1_y, node2_x, node2_y, node3_x, node3_y

    x1,y1,x2,y2,x3,y3 = get_node_xy_value()
    return x1,y1,x2,y2,x3,y3


def getNodeAddress(identifier):
    # get attendance session
    address1=identifier.node1
    address2=identifier.node2
    address3=identifier.node3
    return(address1, address2, address3)


def get_x_y(student, session):

    def triangulate(d1, d2, d3, x1, y1, x2, y2, x3, y3):
        import math
        R1 = [float(x1), float(y1)]
        R2 = [float(x2), float(y2)]
        R3 = [float(x3), float(y3)]

        # if d1 ,d2 and d3 in known
        # calculate A ,B and C coifficents
        A = R1[0] ** 2 + R1[1] ** 2 - (d1) ** 2
        B = R2[0] ** 2 + R2[1] ** 2 - (d2) ** 2
        C = R3[0] ** 2 + R3[1] ** 2 - (d3) ** 2

        X32 = R3[0] - R2[0]
        X13 = R1[0] - R3[0]
        X21 = R2[0] - R1[0]

        Y32 = R3[1] - R2[1]
        Y13 = R1[1] - R3[1]
        Y21 = R2[1] - R1[1]

        x = (A * Y32 + B * Y13 + C * Y21) / (2.0 * (R1[0] * Y32 + R2[0] * Y13 + R3[0] * Y21))
        y = (A * X32 + B * X13 + C * X21) / (2.0 * (R1[1] * X32 + R2[1] * X13 + R3[1] * X21))
        
        # prompt the result
        print("(x,y) = (" + str(x) + "," + str(y) + ")")
        return x,y


    session_obj = AttendanceSession.objects.all().filter(session=session)[0]
    node1_adr, node2_adr, node3_adr = getNodeAddress(session_obj)
    x1_anchor, y1_anchor, x2_anchor, y2_anchor, x3_anchor, y3_anchor = getNodeLocation(session)
    d1,d2,d3 = float(0.0),float(0.0),float(0.0)

    # get all distance values from 3 points
    for each in student_data_arr:
        if str(each[0]) == str(student):
            # Check is user receives all three nodes
            if str(each[1]) == str(node1_adr):
                d1=float(each[3])
            else:
                d1=99
            
            if str(each[1]) == str(node2_adr):
                d2=float(each[3])
            else:
                d2=99
            
            if str(each[1]) == str(node3_adr):
                d3=float(each[3])
            else:
                d3=99
        else:
            pass

    x_val, y_val = triangulate(d1,d2,d3,x1_anchor,y1_anchor,x2_anchor,y2_anchor,x3_anchor,y3_anchor)
    return x_val, y_val


def get_userkey(student, collection):
    for each in collection:
        student_id = str(each[1])
        key = str(each[nanumber])
        if student_id == str(student):
            return key
        else:
            key = errkey_value
    return key


def get_closest(student):
    for each in student_data_arr:
        condition1 = bool(str(each[0])==str(student))
        condition2 = bool(float(abs(each[3])) >= close_proximity_value)
        if condition1 and condition2:
            close_objs.append([str(each[0]),str(each[1]),str(each[3])])
    return


def clear_arrays():
    student_list_arr.clear()
    student_data_arr.clear()
    student_location_arr.clear()


def verify_nodes(var_id_student, var_obj_session):
    point1, point2, point3 = False, False, False
    node1, node2, node3 = getNodeAddress(var_obj_session)
    # get all distance values from 3 points
    for each_signal in student_data_arr:
        # If its the student's
        if str(each_signal[0]) == str(var_id_student):
            # Check is user receives all three nodes
            if str(each_signal[1]) == str(node1):
                point1 = bool(True)
            if str(each_signal[1]) == str(node2):
                point2 = bool(True)
            if str(each_signal[1]) == str(node3):
                point3 = bool(True)
        # If not, go to next
        else:
            pass

    if point1==True and point2==True and point3==True:
        return True
    else:            
        return False


def main_localization(session):
    message = ''
    student_id = ''
    clear_arrays()
    start_time = markTime()					# Get action's timestamp
    dbname = get_database()					# Get the database and connect
    collection_name = dbname[collect_name]	# Read from database table, based on value passed.
    
    # Extract VALUES from db and save array
    # Then convert to numpy array to make better use of data
    
    arr = []
    for x in collection_name.find():
        res_array = np.array(list(x.values()))
        arr.append(res_array)
    numpyArr=np.asarray(arr)				# Numpy array of all recorded data
    dbColToArr(numpyArr)					# Call created function

    # Iterate over list of students
    # And get x,y values using created function
    for each_student in student_list_arr:
        student_id = each_student
        user_key = get_userkey(student_id, arr)
        if user_key == errkey_value:
            message+=str("Error occured with student id")
        message+=str("DEBUGGGG: key is {}={} ".format(student_id, user_key))

        obj_session = AttendanceSession.objects.all().filter(session=session)[0]
        rssi = 1
        # Get user details
        obj_userProfile = UserProfile.objects.all().filter(key=user_key)[0]
        obj_userProfile.student_id = student_id 
        obj_userProfile.save()

        # Find user using key from web to key from ble
        try:
            obj_user = User.objects.all().filter(username=obj_userProfile.user.username)[0]

        # Index error means no one is there
        except IndexError:
            message+=str("No students are using ble app. No localized data")
            return message

       # If student received all 3 signals
        localized = verify_nodes(student_id, obj_session)
        message += str(localized)
        if localized: 
        # Get scaled x and y
            x,y = get_x_y(student_id, session)
                
            #student_id = each_student
            get_closest(student_id)

            #x,y,user_key=get_x_y(student_id, session)	# Call created function to get location
            if not Localization.objects.all().filter(user=obj_user, session=obj_session).exists():
                entry = Localization.objects.create(user=obj_user, rssi=rssi, session=obj_session, x_val=float(round(x,2)), y_val=float(round(y,2)))
                entry.save()
                message+=str("{} has location ({},{})".format(student_id,x,y))
            else:
                # Update valies
                loc_obj = Localization.objects.all().filter(user=obj_user, session=obj_session)[0]
                Localization.objects.filter(pk=loc_obj.id).update(x_val = float(round(x,2)), y_val = float(round(y,2)))
                #message+=str("Updated. {} has location ({},{})".format(loc_obj.user,loc_obj.x_val,loc_obj.y_val))
        else: 
            message+=str("Student {}'s signal is inaccurate (lost 1 of the signals). Try updating later.".format(obj_userProfile.user.username))
        # TODO: Filter through list, and get only nearby devices
        #   As decision, only get device address that are 80dBm or less
        #   From a website, that is 3.5m
        # Call created function
        #   To save to array close_objs
       

    data_arr = np.asarray(student_data_arr)
    end_time = markTime()

    # TODO: Delete. Used for debugging.
    message+=str("\nThere are {} students registered".format(len(student_list_arr)))
    return message
