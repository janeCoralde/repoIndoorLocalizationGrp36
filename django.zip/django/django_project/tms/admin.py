from .models import *
from django.contrib import admin
from django.contrib.auth.models import Group, User
from django.contrib.auth.admin import UserAdmin

# This hide the groups option from the admin app page
admin.site.unregister(Group)


# Extend the default user model with the UserProfile model
class UserProfileInline(admin.StackedInline):
    model = UserProfile
    verbose_name = 'Grouping Management'


# This is to customize the display of the User Model in the admin page
class CustomUserAdmin(UserAdmin):
    readonly_fields = ['is_staff']

    # Fields shown when adding a new user
    add_fieldsets = (
        (None, {
            'fields': ('username', 'password1', 'password2', 'first_name', 'last_name'),
        }),
    )

    # Fields shown when modifying an existing user
    fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'password', 'first_name', 'last_name'),
        }),
    )

    # list of columns displayed for that model.
    # TODO: Add email address
    list_display = ('username', 'first_name', 'last_name')

    # list of filters on the right hand side of the page
    # TODO: Check if needed later
    # list_filter = ('is_staff',)

    # Inline is needed to integrate UserProfile Table inside the User management
    inlines = [UserProfileInline]


class ClassCourseMemberInline(admin.TabularInline):
    model = ClassCourseMember


class CustomClassCourse(admin.ModelAdmin):
    list_display = ('name', 'description', 'status', 'instructor', 'location', 'student_names')
    list_filter = ('status', 'location',)
    def has_add_permission(self, request):
        return True
    def has_delete_permission(self, request, obj=None):
        return True


class CustomLocalization(admin.ModelAdmin):
    list_display = ('user', 'session', 'timestamp', 'x_val', 'y_val')
    # TODO: Enable filtering for course, once added
    # TODO: Set to false, should be getting data from API
    def has_add_permission(self, request):
        return True
    def has_delete_permission(self, request, obj=None):
        return True


class CustomAttendanceSession(admin.ModelAdmin):
    list_display = ('session', 'student_names', 'description', 'course', 'node1', 'node2', 'node3', 'node1_location', 'node2_location', 'node3_location')
    list_filter = ('session', 'course')
    def has_add_permission(self, request):
        return True
    def has_delete_permission(self, request, obj=None):
        return True


class CustomAttendanceMember(admin.ModelAdmin):
    list_display = ('user', 'timestamp')
    list_filter = ('session', 'timestamp')


# End of code shows registered and unregistered classes
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)
admin.site.register(ClassCourse, CustomClassCourse)
admin.site.register(Localization, CustomLocalization)
admin.site.register(AttendanceSession, CustomAttendanceSession)
admin.site.register(AttendanceMember, CustomAttendanceMember)
